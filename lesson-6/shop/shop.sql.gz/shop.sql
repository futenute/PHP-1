-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 17 2020 г., 09:36
-- Версия сервера: 5.6.43
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `text` text NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `name`, `text`, `date_create`) VALUES
(3, 'Иван', 'Хорошо', '2020-11-16 09:35:36'),
(6, 'Соня Чернова', 'ffff', '2020-11-16 12:03:05'),
(7, 'Сергей', 'авлодыадовылоыа', '2020-11-16 12:28:48'),
(8, 'Ирина', 'ааыыыыы', '2020-11-16 12:28:57'),
(9, 'Степан', 'рвчпвыпвп', '2020-11-16 12:29:05');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `small_img` varchar(50) NOT NULL,
  `big_img` varchar(50) NOT NULL,
  `short_desc` text NOT NULL,
  `long_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `small_img`, `big_img`, `short_desc`, `long_desc`) VALUES
(1, 'Суккуленты', 349, 'img/small/succulent.jpg', 'img/big/succulent.jpg', 'Комнатное растение', 'Растет в засушливых регионах по всему миру.\r\nПростое в уходе растение.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к холодной воде и недостаточному поливу, что может выражаться в опадании листьев.'),
(2, 'Хамедорея Элеганс', 129, 'img/small/hamedoreya-elegans.jpg', 'img/big/hamedoreya-elegans.jpg', 'Растение в горшке, Хамедорея изящная', 'Культивированное растение.Для использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(3, 'Каллуна', 299, 'img/small/calluna.jpg', 'img/big/calluna.jpg', 'Растение в горшке', 'Украсьте дом растениями в подходящих для вашего интерьера кашпо.\r\nОбласть естественного распространения: Европа.\r\nДля использования вне помещения.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(4, 'Фикус Бенджамина', 499, 'img/small/ficus.jpg', 'img/big/ficus.jpg', 'Растение в горшке, Фикус Бенджамина \"Наташа\"', 'Область естественного распространения: Юго-Восточная Азия, Австралия и Африка.\r\nБыстрый рост.\r\nЭто растение чувствительно к сквознякам.\r\nРастение чувствительно к перемещениям.\r\nРастение чувствительно к недостатку света и перемещениям, что может выражаться в опадании листьев.'),
(5, 'Дипсис Желтоватый', 2999, 'img/small/dypsis.jpg', 'img/big/dypsis.jpg', 'Растение в горшке, Хризалидокарпус желтоватый', 'Область естественного распространения: Мадагаскар.\r\nИдеальное растение для офиса.\r\nЭто растение чувствительно к сквознякам.\r\nДля использования в помещении.\r\nРазмещать в освещенном месте, избегая воздействия прямых солнечных лучей.'),
(6, 'Алоэ Вера', 349, 'img/small/aloe-vera.jpg', 'img/big/aloe-vera.jpg', 'Растение в горшке, Алоэ', 'Область естественного распространения: Южная Африка.\r\nПростое в уходе растение.\r\nМедленный рост.\r\nПредпочитает теплую среду.\r\nДля использования в помещении.\r\nРазмещать в хорошо освещенном солнечном месте.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
